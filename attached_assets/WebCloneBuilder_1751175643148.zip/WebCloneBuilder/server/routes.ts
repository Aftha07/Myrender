import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { loginSchema, resetPasswordSchema } from "@shared/schema";
import bcrypt from "bcrypt";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Company user login
  app.post('/api/auth/company-login', async (req, res) => {
    try {
      const validatedData = loginSchema.parse(req.body);
      const { email, password } = validatedData;

      // Verify user credentials
      const user = await storage.verifyCompanyUserPassword(email, password);
      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      if (user.isActive !== "true") {
        return res.status(401).json({ message: "Account is inactive" });
      }

      // Update last login
      await storage.updateCompanyUserLastLogin(user.id);

      // Set session
      (req.session as any).companyUser = {
        id: user.id,
        email: user.email,
        companyId: user.companyId,
      };

      res.json({
        success: true,
        user: {
          id: user.id,
          email: user.email,
          companyId: user.companyId,
        },
      });
    } catch (error: any) {
      console.error("Company login error:", error);
      if (error?.name === 'ZodError') {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Company user logout
  app.post('/api/auth/company-logout', (req, res) => {
    (req.session as any).companyUser = null;
    res.json({ success: true });
  });

  // Get current company user
  app.get('/api/auth/company-user', (req, res) => {
    const companyUser = (req.session as any).companyUser;
    if (!companyUser) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    res.json(companyUser);
  });

  // Password reset request
  app.post('/api/auth/forgot-password', async (req, res) => {
    try {
      const validatedData = resetPasswordSchema.parse(req.body);
      const { email } = validatedData;

      // Check if user exists
      const user = await storage.getCompanyUserByEmail(email);
      if (!user) {
        // Don't reveal if email exists for security
        return res.json({ success: true, message: "If the email exists, a reset link has been sent" });
      }

      // Create reset token
      const token = await storage.createPasswordResetToken(email);

      // TODO: Send email with reset link
      console.log(`Password reset token for ${email}: ${token}`);

      res.json({ success: true, message: "If the email exists, a reset link has been sent" });
    } catch (error: any) {
      console.error("Password reset error:", error);
      if (error?.name === 'ZodError') {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Password reset failed" });
    }
  });

  // Create test company users (development only)
  app.post('/api/auth/create-test-users', async (req, res) => {
    try {
      // Create test users for demo purposes
      const testUsers = [
        { email: 'demo@company.com', password: 'password123', companyId: 'COMP001' },
        { email: 'admin@alrajhi.com', password: 'admin123', companyId: 'COMP002' },
        { email: 'manager@sabic.com', password: 'manager123', companyId: 'COMP003' }
      ];

      const createdUsers = [];
      for (const userData of testUsers) {
        try {
          const existingUser = await storage.getCompanyUserByEmail(userData.email);
          if (!existingUser) {
            const user = await storage.createCompanyUser(userData);
            createdUsers.push(user.email);
          }
        } catch (error) {
          console.log(`User ${userData.email} might already exist`);
        }
      }

      res.json({ 
        success: true, 
        message: 'Test users created',
        users: createdUsers,
        loginCredentials: testUsers.map(u => ({ email: u.email, password: u.password }))
      });
    } catch (error: any) {
      console.error("Error creating test users:", error);
      res.status(500).json({ message: "Failed to create test users" });
    }
  });

  // Reset password with token
  app.post('/api/auth/reset-password', async (req, res) => {
    try {
      const { token, password } = req.body;

      if (!token || !password) {
        return res.status(400).json({ message: "Token and password are required" });
      }

      if (password.length < 6) {
        return res.status(400).json({ message: "Password must be at least 6 characters" });
      }

      // Validate token
      const tokenData = await storage.validatePasswordResetToken(token);
      if (!tokenData) {
        return res.status(400).json({ message: "Invalid or expired reset token" });
      }

      // Hash new password
      const hashedPassword = await bcrypt.hash(password, 12);

      // Update password
      await storage.updateCompanyUserPassword(tokenData.email, hashedPassword);

      res.json({ success: true, message: "Password updated successfully" });
    } catch (error: any) {
      console.error("Password reset error:", error);
      res.status(500).json({ message: "Password reset failed" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
