import {
  users,
  companyUsers,
  passwordResetTokens,
  type User,
  type UpsertUser,
  type CompanyUser,
  type InsertCompanyUser,
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import bcrypt from "bcrypt";
import { nanoid } from "nanoid";

// Interface for storage operations
export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Company user operations for VoM login
  getCompanyUserByEmail(email: string): Promise<CompanyUser | undefined>;
  createCompanyUser(user: InsertCompanyUser): Promise<CompanyUser>;
  updateCompanyUserLastLogin(id: string): Promise<void>;
  verifyCompanyUserPassword(email: string, password: string): Promise<CompanyUser | null>;
  
  // Password reset operations
  createPasswordResetToken(email: string): Promise<string>;
  validatePasswordResetToken(token: string): Promise<{ email: string } | null>;
  updateCompanyUserPassword(email: string, hashedPassword: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Company user operations
  async getCompanyUserByEmail(email: string): Promise<CompanyUser | undefined> {
    const [user] = await db
      .select()
      .from(companyUsers)
      .where(eq(companyUsers.email, email.toLowerCase()));
    return user;
  }

  async createCompanyUser(userData: InsertCompanyUser): Promise<CompanyUser> {
    const hashedPassword = await bcrypt.hash(userData.password, 12);
    const [user] = await db
      .insert(companyUsers)
      .values({
        id: nanoid(),
        email: userData.email.toLowerCase(),
        password: hashedPassword,
        companyId: userData.companyId,
      })
      .returning();
    return user;
  }

  async updateCompanyUserLastLogin(id: string): Promise<void> {
    await db
      .update(companyUsers)
      .set({ lastLoginAt: new Date() })
      .where(eq(companyUsers.id, id));
  }

  async verifyCompanyUserPassword(email: string, password: string): Promise<CompanyUser | null> {
    const user = await this.getCompanyUserByEmail(email);
    if (!user) return null;

    const isValid = await bcrypt.compare(password, user.password);
    if (!isValid) return null;

    return user;
  }

  // Password reset operations
  async createPasswordResetToken(email: string): Promise<string> {
    const token = nanoid(32);
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

    await db.insert(passwordResetTokens).values({
      id: nanoid(),
      email: email.toLowerCase(),
      token,
      expiresAt,
    });

    return token;
  }

  async validatePasswordResetToken(token: string): Promise<{ email: string } | null> {
    const [resetToken] = await db
      .select()
      .from(passwordResetTokens)
      .where(eq(passwordResetTokens.token, token));

    if (!resetToken || resetToken.expiresAt < new Date()) {
      return null;
    }

    return { email: resetToken.email };
  }

  async updateCompanyUserPassword(email: string, hashedPassword: string): Promise<void> {
    await db
      .update(companyUsers)
      .set({ password: hashedPassword, updatedAt: new Date() })
      .where(eq(companyUsers.email, email.toLowerCase()));
  }
}

export const storage = new DatabaseStorage();
