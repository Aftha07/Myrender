import { useState } from 'react';
import { useTranslation } from '@/lib/i18n';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ArrowLeft, ChevronDown, Plus, Trash2, Calendar } from 'lucide-react';
import { Link } from 'wouter';

interface Language {
  code: string;
  name: string;
}

interface InvoiceCreateProps {
  language: Language;
}

interface ProductLine {
  id: number;
  product: string;
  description: string;
  qty: number;
  unitPrice: number;
  discountPercent: number;
  vatPercent: number;
  vatValue: number;
  amount: number;
}

export default function InvoiceCreate({ language }: InvoiceCreateProps) {
  const { t } = useTranslation(language.code as 'en' | 'ar');
  const [formData, setFormData] = useState({
    referenceId: 'INV0135',
    description: '',
    customer: '',
    invoiceDate: '22-06-2025',
    time: '10:47 pm',
    costCenter: 'Main Center',
    paymentTerm: '',
    supplyDate: '22-06-2025'
  });

  const [productLines, setProductLines] = useState<ProductLine[]>([
    {
      id: 1,
      product: '',
      description: '',
      qty: 1,
      unitPrice: 0,
      discountPercent: 0,
      vatPercent: 15,
      vatValue: 0,
      amount: 0
    }
  ]);

  const [expandedSections, setExpandedSections] = useState({
    termsAndConditions: false,
    notes: false,
    attachments: false
  });

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const addProductLine = () => {
    const newLine: ProductLine = {
      id: productLines.length + 1,
      product: '',
      description: '',
      qty: 1,
      unitPrice: 0,
      discountPercent: 0,
      vatPercent: 15,
      vatValue: 0,
      amount: 0
    };
    setProductLines([...productLines, newLine]);
  };

  const removeProductLine = (id: number) => {
    setProductLines(productLines.filter(line => line.id !== id));
  };

  const updateProductLine = (id: number, field: keyof ProductLine, value: any) => {
    setProductLines(productLines.map(line => {
      if (line.id === id) {
        const updated = { ...line, [field]: value };
        // Calculate amount when relevant fields change
        if (['qty', 'unitPrice', 'discountPercent', 'vatPercent'].includes(field)) {
          const subtotal = updated.qty * updated.unitPrice;
          const discountAmount = subtotal * (updated.discountPercent / 100);
          const afterDiscount = subtotal - discountAmount;
          updated.vatValue = afterDiscount * (updated.vatPercent / 100);
          updated.amount = afterDiscount + updated.vatValue;
        }
        return updated;
      }
      return line;
    }));
  };

  const clearAll = () => {
    setProductLines([{
      id: 1,
      product: '',
      description: '',
      qty: 1,
      unitPrice: 0,
      discountPercent: 0,
      vatPercent: 15,
      vatValue: 0,
      amount: 0
    }]);
  };

  const calculateTotals = () => {
    const subtotal = productLines.reduce((sum, line) => sum + (line.qty * line.unitPrice), 0);
    const totalDiscount = productLines.reduce((sum, line) => sum + (line.qty * line.unitPrice * line.discountPercent / 100), 0);
    const totalVat = productLines.reduce((sum, line) => sum + line.vatValue, 0);
    const total = productLines.reduce((sum, line) => sum + line.amount, 0);
    
    return {
      discount: totalDiscount,
      gross: subtotal - totalDiscount,
      vat: totalVat,
      total
    };
  };

  const totals = calculateTotals();

  return (
    <div className={`min-h-screen bg-gray-50 ${language.code === 'ar' ? 'font-arabic' : ''}`} dir={language.code === 'ar' ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm" className="text-gray-600">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div className="text-sm text-gray-500">
              {t('sales')} / {t('invoices')} / {t('createTaxInvoice')}
            </div>
          </div>
          <div className="text-2xl font-bold text-teal-600">VoM</div>
        </div>
      </div>

      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 bg-white border-r border-gray-200 min-h-screen">
          <div className="p-4">
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-8 h-8 bg-gray-300 rounded-full"></div>
              <div>
                <div className="text-sm font-medium">Welcome مرحبا</div>
                <div className="text-xs text-gray-500">Last Visit Date: 1 hour ago</div>
              </div>
            </div>

            <nav className="space-y-1">
              <div className="bg-teal-600 text-white rounded-lg p-2">
                <div className="text-sm font-medium">{t('sales')}</div>
              </div>
              <div className="ml-4 space-y-1 mt-2">
                <div className="text-sm text-gray-600 py-1">{t('customers')}</div>
                <div className="text-sm text-gray-600 py-1">{t('quotation')}</div>
                <div className="text-sm text-gray-600 py-1">{t('proformaInvoices')}</div>
                <div className="text-sm text-blue-600 py-1 font-medium">{t('invoices')}</div>
                <div className="text-sm text-gray-600 py-1">{t('debitNotes')}</div>
                <div className="text-sm text-gray-600 py-1">{t('creditNote')}</div>
                <div className="text-sm text-gray-600 py-1">{t('customerReceipts')}</div>
                <div className="text-sm text-gray-600 py-1">Sales Transactions</div>
              </div>
            </nav>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Form */}
            <div className="lg:col-span-2 space-y-6">
              {/* Basic Information */}
              <Card>
                <CardContent className="p-6 space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="referenceId">{t('referenceId')}</Label>
                      <Input
                        id="referenceId"
                        value={formData.referenceId}
                        onChange={(e) => setFormData({...formData, referenceId: e.target.value})}
                      />
                    </div>
                    <div></div>
                  </div>

                  <div>
                    <Label htmlFor="description">{t('description')} {t('optional')}</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label htmlFor="customer">{t('customer')} *</Label>
                    <Select value={formData.customer} onValueChange={(value) => setFormData({...formData, customer: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder={t('pleaseSelectCustomer')} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="customer1">Customer 1</SelectItem>
                        <SelectItem value="customer2">Customer 2</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="invoiceDate">{t('invoiceDate')}</Label>
                      <div className="relative">
                        <Input
                          id="invoiceDate"
                          value={formData.invoiceDate}
                          onChange={(e) => setFormData({...formData, invoiceDate: e.target.value})}
                        />
                        <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="time">{t('time')}</Label>
                      <Input
                        id="time"
                        value={formData.time}
                        onChange={(e) => setFormData({...formData, time: e.target.value})}
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="costCenter">{t('costCenter')}</Label>
                    <Select value={formData.costCenter} onValueChange={(value) => setFormData({...formData, costCenter: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Main Center">{t('mainCenter')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="paymentTerm">{t('paymentTerm')} *</Label>
                    <Select value={formData.paymentTerm} onValueChange={(value) => setFormData({...formData, paymentTerm: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder={t('selectPaymentTerm')} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="net30">Net 30</SelectItem>
                        <SelectItem value="net60">Net 60</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="supplyDate">{t('supplyDate')}</Label>
                    <div className="relative">
                      <Input
                        id="supplyDate"
                        value={formData.supplyDate}
                        onChange={(e) => setFormData({...formData, supplyDate: e.target.value})}
                      />
                      <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Products/Services Table */}
              <Card>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>#</TableHead>
                          <TableHead>{t('productsServices')}</TableHead>
                          <TableHead>{t('description')}</TableHead>
                          <TableHead>{t('qty')}</TableHead>
                          <TableHead>{t('unitPrice')}</TableHead>
                          <TableHead>{t('discountPercent')}</TableHead>
                          <TableHead>{t('vatPercent')}</TableHead>
                          <TableHead>{t('vatValue')}</TableHead>
                          <TableHead>{t('amount')}</TableHead>
                          <TableHead></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {productLines.map((line, index) => (
                          <TableRow key={line.id}>
                            <TableCell>{index + 1}</TableCell>
                            <TableCell>
                              <Select value={line.product} onValueChange={(value) => updateProductLine(line.id, 'product', value)}>
                                <SelectTrigger className="w-32">
                                  <SelectValue placeholder="-" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="product1">Product 1</SelectItem>
                                  <SelectItem value="product2">Product 2</SelectItem>
                                </SelectContent>
                              </Select>
                            </TableCell>
                            <TableCell>
                              <Input
                                value={line.description}
                                onChange={(e) => updateProductLine(line.id, 'description', e.target.value)}
                                className="w-32"
                              />
                            </TableCell>
                            <TableCell>
                              <Input
                                type="number"
                                value={line.qty}
                                onChange={(e) => updateProductLine(line.id, 'qty', Number(e.target.value))}
                                className="w-16"
                              />
                            </TableCell>
                            <TableCell>
                              <Input
                                type="number"
                                value={line.unitPrice}
                                onChange={(e) => updateProductLine(line.id, 'unitPrice', Number(e.target.value))}
                                className="w-20"
                              />
                            </TableCell>
                            <TableCell>
                              <Input
                                type="number"
                                value={line.discountPercent}
                                onChange={(e) => updateProductLine(line.id, 'discountPercent', Number(e.target.value))}
                                className="w-16"
                              />
                            </TableCell>
                            <TableCell>
                              <Input
                                type="number"
                                value={line.vatPercent}
                                onChange={(e) => updateProductLine(line.id, 'vatPercent', Number(e.target.value))}
                                className="w-16"
                              />
                            </TableCell>
                            <TableCell>
                              <span className="text-sm">{line.vatValue.toFixed(2)}</span>
                            </TableCell>
                            <TableCell>
                              <span className="text-sm">{line.amount.toFixed(2)}</span>
                            </TableCell>
                            <TableCell>
                              {productLines.length > 1 && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => removeProductLine(line.id)}
                                  className="text-red-600"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>

                    <div className="flex space-x-4">
                      <Button variant="outline" onClick={addProductLine} className="text-blue-600">
                        <Plus className="h-4 w-4 mr-2" />
                        {t('addNewRecord')}
                      </Button>
                      <Button variant="outline" onClick={clearAll}>
                        {t('clearAll')}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Totals */}
              <Card>
                <CardContent className="p-6">
                  <div className="space-y-2 max-w-md ml-auto">
                    <div className="flex justify-between">
                      <span>{t('discount')}</span>
                      <span>{totals.discount.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>{t('gross')}</span>
                      <span>{totals.gross.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>{t('vatPercent')}</span>
                      <span>{totals.vat.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between font-semibold border-t pt-2">
                      <span>{t('totalAmount')}</span>
                      <span>{totals.total.toFixed(2)} ر.س</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Collapsible Sections */}
              <div className="space-y-4">
                <Collapsible open={expandedSections.termsAndConditions} onOpenChange={() => toggleSection('termsAndConditions')}>
                  <CollapsibleTrigger asChild>
                    <Button variant="outline" className="w-full justify-between">
                      {t('termsAndConditions')}
                      <ChevronDown className={`h-4 w-4 transition-transform ${expandedSections.termsAndConditions ? 'rotate-180' : ''}`} />
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <Card className="mt-2">
                      <CardContent className="p-4">
                        <Textarea rows={6} placeholder="Enter terms and conditions..." />
                      </CardContent>
                    </Card>
                  </CollapsibleContent>
                </Collapsible>

                <Collapsible open={expandedSections.notes} onOpenChange={() => toggleSection('notes')}>
                  <CollapsibleTrigger asChild>
                    <Button variant="outline" className="w-full justify-between">
                      {t('notes')}
                      <ChevronDown className={`h-4 w-4 transition-transform ${expandedSections.notes ? 'rotate-180' : ''}`} />
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <Card className="mt-2">
                      <CardContent className="p-4">
                        <Textarea rows={4} placeholder="Enter notes..." />
                      </CardContent>
                    </Card>
                  </CollapsibleContent>
                </Collapsible>

                <Collapsible open={expandedSections.attachments} onOpenChange={() => toggleSection('attachments')}>
                  <CollapsibleTrigger asChild>
                    <Button variant="outline" className="w-full justify-between">
                      {t('attachments')}
                      <ChevronDown className={`h-4 w-4 transition-transform ${expandedSections.attachments ? 'rotate-180' : ''}`} />
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <Card className="mt-2">
                      <CardContent className="p-4">
                        <div className="text-sm text-gray-600 mb-2">{t('attachmentsMaxSize')}</div>
                        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                          <Button variant="outline">
                            {t('chooseFiles')}
                          </Button>
                          <div className="text-sm text-gray-500 mt-2">{t('noFileChosen')}</div>
                        </div>
                      </CardContent>
                    </Card>
                  </CollapsibleContent>
                </Collapsible>
              </div>
            </div>

            {/* Right Column - Customer Details */}
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>{t('customerDetails')}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-sm text-gray-600">{t('phone')}</Label>
                    <div className="text-sm">-</div>
                  </div>
                  <div>
                    <Label className="text-sm text-gray-600">{t('customerEmail')}</Label>
                    <div className="text-sm">-</div>
                  </div>
                  <div>
                    <Label className="text-sm text-gray-600">{t('outstandingBalance')}</Label>
                    <div className="text-sm">-</div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Footer */}
          <div className="mt-8 text-center text-sm text-gray-500">
            <div>Value of Money</div>
            <div>All rights reserved © 2025 VoM.</div>
          </div>
        </div>
      </div>
    </div>
  );
}