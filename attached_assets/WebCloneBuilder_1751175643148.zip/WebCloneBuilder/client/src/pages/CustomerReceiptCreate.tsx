import { useState } from 'react';
import { useTranslation } from '@/lib/i18n';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Calendar } from 'lucide-react';
import { Link } from 'wouter';

interface Language {
  code: string;
  name: string;
}

interface CustomerReceiptCreateProps {
  language: Language;
}

export default function CustomerReceiptCreate({ language }: CustomerReceiptCreateProps) {
  const { t } = useTranslation(language.code as 'en' | 'ar');
  const [formData, setFormData] = useState({
    referenceId: 'SRC0005',
    description: '',
    customer: '',
    paymentDate: '22-06-2025',
    costCenter: 'Main Center',
    paymentAccount: 'Cash',
    paymentAmount: '41771.69',
    kind: 'Received'
  });

  return (
    <div className={`min-h-screen bg-gray-50 ${language.code === 'ar' ? 'font-arabic' : ''}`} dir={language.code === 'ar' ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm" className="text-gray-600">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div className="text-sm text-gray-500">
              {t('sales')} / {t('customerReceipts')} / {t('create')}
            </div>
          </div>
          <div className="text-2xl font-bold text-teal-600">VoM</div>
          <Button variant="outline" size="sm" className="border-teal-600 text-teal-600">
            <div className="w-4 h-4 border border-teal-600"></div>
          </Button>
        </div>
      </div>

      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 bg-white border-r border-gray-200 min-h-screen">
          <div className="p-4">
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-8 h-8 bg-gray-300 rounded-full"></div>
              <div>
                <div className="text-sm font-medium">Welcome مرحبا</div>
                <div className="text-xs text-gray-500">Last Visit Date: 1 hour ago</div>
              </div>
            </div>

            <nav className="space-y-1">
              <div className="bg-teal-600 text-white rounded-lg p-2">
                <div className="text-sm font-medium">{t('sales')}</div>
              </div>
              <div className="ml-4 space-y-1 mt-2">
                <div className="text-sm text-gray-600 py-1">{t('customers')}</div>
                <div className="text-sm text-gray-600 py-1">{t('quotation')}</div>
                <div className="text-sm text-gray-600 py-1">{t('proformaInvoices')}</div>
                <div className="text-sm text-gray-600 py-1">{t('invoices')}</div>
                <div className="text-sm text-gray-600 py-1">{t('debitNotes')}</div>
                <div className="text-sm text-gray-600 py-1">{t('creditNote')}</div>
                <div className="text-sm text-blue-600 py-1 font-medium">{t('customerReceipts')}</div>
                <div className="text-sm text-gray-600 py-1">Sales Transactions</div>
              </div>
            </nav>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Form */}
            <div className="lg:col-span-2">
              <Card>
                <CardContent className="p-6 space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="referenceId">{t('referenceId')}</Label>
                      <Input
                        id="referenceId"
                        value={formData.referenceId}
                        onChange={(e) => setFormData({...formData, referenceId: e.target.value})}
                      />
                    </div>
                    <div></div>
                  </div>

                  <div>
                    <Label htmlFor="description">{t('description')} {t('optional')}</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label htmlFor="customer">{t('customer')}</Label>
                    <Select value={formData.customer} onValueChange={(value) => setFormData({...formData, customer: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder={t('pleaseSelectCustomer')} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="customer1">Customer 1</SelectItem>
                        <SelectItem value="customer2">Customer 2</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="paymentDate">{t('paymentDate')}</Label>
                    <div className="relative">
                      <Input
                        id="paymentDate"
                        value={formData.paymentDate}
                        onChange={(e) => setFormData({...formData, paymentDate: e.target.value})}
                      />
                      <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="costCenter">{t('costCenter')}</Label>
                    <Select value={formData.costCenter} onValueChange={(value) => setFormData({...formData, costCenter: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Main Center">{t('mainCenter')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="paymentAccount">{t('paymentAccount')}</Label>
                    <Select value={formData.paymentAccount} onValueChange={(value) => setFormData({...formData, paymentAccount: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Cash">{t('cash')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="paymentAmount">{t('paymentAmount')}</Label>
                    <Input
                      id="paymentAmount"
                      value={formData.paymentAmount}
                      onChange={(e) => setFormData({...formData, paymentAmount: e.target.value})}
                    />
                  </div>

                  <div>
                    <Label htmlFor="kind">{t('kind')}</Label>
                    <Select value={formData.kind} onValueChange={(value) => setFormData({...formData, kind: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Received">{t('received')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right Column - Customer Details */}
            <div>
              <Card>
                <CardContent className="p-6 space-y-4">
                  <div className="text-lg font-semibold">{t('customerDetails')}</div>
                  <div>
                    <div className="text-sm text-gray-600">{t('phone')}</div>
                    <div className="text-sm">-</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600">{t('customerEmail')}</div>
                    <div className="text-sm">-</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600">{t('outstandingBalance')}</div>
                    <div className="text-sm">-</div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Footer */}
          <div className="mt-8 text-center text-sm text-gray-500">
            <div>Value of Money</div>
            <div>All rights reserved © 2025 VoM.</div>
          </div>
        </div>
      </div>
    </div>
  );
}