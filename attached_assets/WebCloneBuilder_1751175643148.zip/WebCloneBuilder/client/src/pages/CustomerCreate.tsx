import { useState } from 'react';
import { useTranslation } from '@/lib/i18n';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { ArrowLeft, Plus } from 'lucide-react';
import { Link } from 'wouter';

interface Language {
  code: string;
  name: string;
}

interface CustomerCreateProps {
  language: Language;
}

export default function CustomerCreate({ language }: CustomerCreateProps) {
  const { t } = useTranslation(language.code as 'en' | 'ar');
  const [formData, setFormData] = useState({
    code: '22',
    customerName: '',
    account: 'Accounts Receivables',
    phone: 'Saudi Arabia (+966)',
    email: '',
    vatRegistrationNumber: '',
    openingBalance: '',
    streetName: '',
    city: '',
    country: '',
    postalCode: '',
    createAssociatedAccount: false
  });

  return (
    <div className={`min-h-screen bg-gray-50 ${language.code === 'ar' ? 'font-arabic' : ''}`} dir={language.code === 'ar' ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm" className="text-gray-600">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div className="text-sm text-gray-500">
              {t('sales')} / {t('customers')} / {t('create')}
            </div>
          </div>
          <div className="text-2xl font-bold text-teal-600">VoM</div>
          <Button variant="outline" size="sm" className="border-teal-600 text-teal-600">
            <div className="w-4 h-4 border border-teal-600"></div>
          </Button>
        </div>
      </div>

      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 bg-white border-r border-gray-200 min-h-screen">
          <div className="p-4">
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-8 h-8 bg-gray-300 rounded-full"></div>
              <div>
                <div className="text-sm font-medium">Welcome مرحبا</div>
                <div className="text-xs text-gray-500">Last Visit Date: 1 hour ago</div>
              </div>
            </div>

            <nav className="space-y-1">
              <div className="bg-teal-600 text-white rounded-lg p-2">
                <div className="text-sm font-medium">{t('sales')}</div>
              </div>
              <div className="ml-4 space-y-1 mt-2">
                <div className="text-sm text-blue-600 py-1 font-medium">{t('customers')}</div>
                <div className="text-sm text-gray-600 py-1">{t('quotation')}</div>
                <div className="text-sm text-gray-600 py-1">{t('proformaInvoices')}</div>
                <div className="text-sm text-gray-600 py-1">{t('invoices')}</div>
                <div className="text-sm text-gray-600 py-1">{t('debitNotes')}</div>
                <div className="text-sm text-gray-600 py-1">{t('creditNote')}</div>
                <div className="text-sm text-gray-600 py-1">{t('customerReceipts')}</div>
                <div className="text-sm text-gray-600 py-1">Sales Transactions</div>
              </div>
            </nav>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Left Column - Basic Info */}
            <div>
              <Card>
                <CardContent className="p-6 space-y-4">
                  <div>
                    <Label htmlFor="code">{t('code')} *</Label>
                    <Input
                      id="code"
                      value={formData.code}
                      onChange={(e) => setFormData({...formData, code: e.target.value})}
                    />
                  </div>

                  <div>
                    <Label htmlFor="customerName">{t('customerName')} *</Label>
                    <Input
                      id="customerName"
                      value={formData.customerName}
                      onChange={(e) => setFormData({...formData, customerName: e.target.value})}
                    />
                  </div>

                  <div>
                    <Label htmlFor="account">{t('account')}</Label>
                    <Select value={formData.account} onValueChange={(value) => setFormData({...formData, account: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Accounts Receivables">{t('accountsReceivables')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="createAssociatedAccount"
                      checked={formData.createAssociatedAccount}
                      onCheckedChange={(checked) => setFormData({...formData, createAssociatedAccount: checked as boolean})}
                    />
                    <Label htmlFor="createAssociatedAccount" className="text-sm">
                      {t('createAssociatedAccount')}
                    </Label>
                  </div>

                  <div>
                    <Label htmlFor="phone">Phone</Label>
                    <Select value={formData.phone} onValueChange={(value) => setFormData({...formData, phone: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Saudi Arabia (+966)">Saudi Arabia العربية السعودية (+966)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                    />
                  </div>

                  <div>
                    <Label htmlFor="vatRegistrationNumber">{t('vatRegistrationNumber')}</Label>
                    <Input
                      id="vatRegistrationNumber"
                      value={formData.vatRegistrationNumber}
                      onChange={(e) => setFormData({...formData, vatRegistrationNumber: e.target.value})}
                    />
                  </div>

                  <div>
                    <Label htmlFor="openingBalance">{t('openingBalance')}</Label>
                    <div className="relative">
                      <Input
                        id="openingBalance"
                        value={formData.openingBalance}
                        onChange={(e) => setFormData({...formData, openingBalance: e.target.value})}
                      />
                      <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500">ر.س</span>
                    </div>
                  </div>

                  <div>
                    <Button variant="outline" className="text-blue-600 border-blue-600">
                      <Plus className="h-4 w-4 mr-2" />
                      {t('addYourCustomFields')}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right Column - Billing Address */}
            <div>
              <Card>
                <CardContent className="p-6 space-y-4">
                  <div className="text-lg font-semibold">{t('billingAddress')}</div>
                  
                  <div>
                    <Label htmlFor="streetName">{t('streetName')}</Label>
                    <Input
                      id="streetName"
                      value={formData.streetName}
                      onChange={(e) => setFormData({...formData, streetName: e.target.value})}
                    />
                  </div>

                  <div>
                    <Label htmlFor="city">{t('city')}</Label>
                    <Input
                      id="city"
                      value={formData.city}
                      onChange={(e) => setFormData({...formData, city: e.target.value})}
                    />
                  </div>

                  <div>
                    <Label htmlFor="country">{t('country')}</Label>
                    <Input
                      id="country"
                      value={formData.country}
                      onChange={(e) => setFormData({...formData, country: e.target.value})}
                    />
                  </div>

                  <div>
                    <Label htmlFor="postalCode">{t('postalCode')}</Label>
                    <Input
                      id="postalCode"
                      value={formData.postalCode}
                      onChange={(e) => setFormData({...formData, postalCode: e.target.value})}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Footer */}
          <div className="mt-8 text-center text-sm text-gray-500">
            <div>Value of Money</div>
            <div>All rights reserved © 2025 VoM.</div>
          </div>
        </div>
      </div>
    </div>
  );
}