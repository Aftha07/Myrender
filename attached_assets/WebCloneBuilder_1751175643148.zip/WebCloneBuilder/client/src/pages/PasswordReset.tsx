import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { ReCaptcha } from '@/components/ReCaptcha';
import { LanguageToggle } from '@/components/LanguageToggle';
import { Language, useTranslation } from '@/lib/i18n';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Loader2, ArrowLeft } from 'lucide-react';
import { Link, useLocation } from 'wouter';

export default function PasswordReset() {
  const [, setLocation] = useLocation();
  const [language, setLanguage] = useState<Language>('en');
  const { t } = useTranslation(language);
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    email: '',
    recaptcha: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    // Update HTML attributes for language and direction
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.body.className = `bg-slate-50 min-h-screen font-${language === 'ar' ? 'arabic' : 'english'}`;
  }, [language]);

  const resetMutation = useMutation({
    mutationFn: async (data: { email: string; recaptcha: string }) => {
      const response = await apiRequest('POST', '/api/auth/forgot-password', data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: t('resetLinkSent'),
        description: data.message,
      });
      setFormData({ email: '', recaptcha: '' });
    },
    onError: (error: any) => {
      console.error('Password reset error:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to send reset link',
        variant: 'destructive',
      });
    },
  });

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.email) {
      newErrors.email = t('emailRequired');
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = t('emailInvalid');
    }

    if (!formData.recaptcha) {
      newErrors.recaptcha = t('recaptchaRequired');
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      resetMutation.mutate(formData);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleRecaptchaVerify = (token: string) => {
    setFormData(prev => ({ ...prev, recaptcha: token }));
    if (errors.recaptcha) {
      setErrors(prev => ({ ...prev, recaptcha: '' }));
    }
  };

  const handleRecaptchaExpired = () => {
    setFormData(prev => ({ ...prev, recaptcha: '' }));
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* VoM Logo */}
            <div className="flex-shrink-0">
              <img
                src="https://secondsupport.getvom.com/assets/images/logo/colored-logo.png"
                alt="VoM Logo"
                className="h-8 w-auto"
              />
            </div>

            {/* Language Toggle */}
            <div className="flex items-center space-x-4">
              <LanguageToggle
                currentLanguage={language}
                onLanguageChange={setLanguage}
              />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <Card className="w-full max-w-md shadow-lg border border-slate-200">
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-semibold text-gray-900">
                {t('resetPasswordTitle')}
              </h2>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                  {t('emailLabel')}
                </Label>
                <Input
                  type="email"
                  id="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  placeholder={t('emailPlaceholder')}
                  className={`w-full ${errors.email ? 'border-red-500' : 'border-slate-300'} focus:ring-2 focus:ring-blue-700 focus:border-blue-700`}
                  disabled={resetMutation.isPending}
                />
                {errors.email && (
                  <p className="mt-1 text-sm text-red-600">{errors.email}</p>
                )}
              </div>

              <div className="flex justify-center">
                <ReCaptcha
                  onVerify={handleRecaptchaVerify}
                  onExpired={handleRecaptchaExpired}
                />
                {errors.recaptcha && (
                  <p className="mt-1 text-sm text-red-600">{errors.recaptcha}</p>
                )}
              </div>

              <Button
                type="submit"
                disabled={resetMutation.isPending}
                className="w-full bg-blue-700 hover:bg-blue-800 text-white font-medium py-3 transition-all duration-200"
              >
                {resetMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Sending...
                  </>
                ) : (
                  t('sendResetLink')
                )}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <Link
                href="/"
                className="inline-flex items-center text-sm text-blue-700 hover:text-blue-800 transition-colors duration-200"
              >
                <ArrowLeft className="mr-1 h-4 w-4" />
                {t('backToLogin')}
              </Link>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
