import { useState, useEffect } from 'react';
import { LoginForm } from '@/components/LoginForm';
import { LanguageToggle } from '@/components/LanguageToggle';
import { Language } from '@/lib/i18n';
import { useLocation } from 'wouter';

export default function Landing() {
  const [, setLocation] = useLocation();
  const [language, setLanguage] = useState<Language>('en');

  useEffect(() => {
    // Update HTML attributes for language and direction
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.body.className = `bg-slate-50 min-h-screen font-${language === 'ar' ? 'arabic' : 'english'}`;
  }, [language]);

  const handleLoginSuccess = () => {
    setLocation('/dashboard');
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* VoM Logo */}
            <div className="flex-shrink-0">
              <img
                src="https://secondsupport.getvom.com/assets/images/logo/colored-logo.png"
                alt="VoM Logo"
                className="h-8 w-auto"
              />
            </div>

            {/* Language Toggle */}
            <div className="flex items-center space-x-4">
              <LanguageToggle
                currentLanguage={language}
                onLanguageChange={setLanguage}
              />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <LoginForm language={language} onLoginSuccess={handleLoginSuccess} />
      </main>
    </div>
  );
}
