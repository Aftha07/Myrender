import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LanguageToggle } from '@/components/LanguageToggle';
import { Language, useTranslation } from '@/lib/i18n';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useLocation, Link } from 'wouter';
import { 
  LogOut, 
  FileText, 
  DollarSign, 
  TrendingUp, 
  Receipt, 
  CreditCard,
  Users,
  ShoppingCart,
  BarChart3,
  Calendar,
  Download,
  Plus,
  Eye,
  Edit,
  Trash2,
  Search,
  Filter
} from 'lucide-react';

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const [language, setLanguage] = useState<Language>('en');
  const { t } = useTranslation(language);
  const { toast } = useToast();

  // Check authentication status
  const { data: companyUser, isLoading } = useQuery({
    queryKey: ['/api/auth/company-user'],
    retry: false,
  });

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.body.className = `bg-slate-50 min-h-screen font-${language === 'ar' ? 'arabic' : 'english'}`;
  }, [language]);

  useEffect(() => {
    if (!isLoading && !companyUser) {
      setLocation('/');
    }
  }, [companyUser, isLoading, setLocation]);

  const logoutMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('POST', '/api/auth/company-logout');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/auth/company-user'] });
      toast({
        title: 'Logged out successfully',
        description: 'You have been logged out',
      });
      setLocation('/');
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-slate-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (!companyUser) {
    return null;
  }

  // Mock dashboard data based on VoM's features
  const dashboardStats = {
    totalRevenue: 125750.50,
    monthlyRevenue: 24300.00,
    invoicesSent: 47,
    unpaidInvoices: 8,
    customers: 156,
    expenses: 15420.75
  };

  const recentInvoices = [
    { id: 'INV-001', customer: 'Al Rajhi Company', amount: 5250.00, status: 'paid', date: '2025-01-25' },
    { id: 'INV-002', customer: 'Saudi Basic Industries', amount: 12750.00, status: 'pending', date: '2025-01-24' },
    { id: 'INV-003', customer: 'National Commercial Bank', amount: 3500.00, status: 'overdue', date: '2025-01-22' },
    { id: 'INV-004', customer: 'SABIC', amount: 8900.00, status: 'paid', date: '2025-01-21' },
    { id: 'INV-005', customer: 'STC', amount: 4200.00, status: 'pending', date: '2025-01-20' }
  ];

  const recentExpenses = [
    { id: 'EXP-001', description: 'Office Rent', amount: 6000.00, category: 'Rent', date: '2025-01-25' },
    { id: 'EXP-002', description: 'Internet & Utilities', amount: 850.00, category: 'Utilities', date: '2025-01-24' },
    { id: 'EXP-003', description: 'Office Supplies', amount: 420.75, category: 'Supplies', date: '2025-01-23' },
    { id: 'EXP-004', description: 'Marketing Campaign', amount: 2500.00, category: 'Marketing', date: '2025-01-22' }
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <img
                src="https://secondsupport.getvom.com/assets/images/logo/colored-logo.png"
                alt="VoM Logo"
                className="h-8 w-auto"
              />
              <nav className="hidden md:flex space-x-6">
                <Button variant="ghost" className="text-blue-700">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  {t('dashboard')}
                </Button>
                <Button variant="ghost">
                  <FileText className="h-4 w-4 mr-2" />
                  {t('invoices')}
                </Button>
                <Button variant="ghost">
                  <Receipt className="h-4 w-4 mr-2" />
                  {t('expenses')}
                </Button>
                <Button variant="ghost">
                  <Users className="h-4 w-4 mr-2" />
                  {t('customers')}
                </Button>
              </nav>
            </div>

            <div className="flex items-center space-x-4">
              <LanguageToggle
                currentLanguage={language}
                onLanguageChange={setLanguage}
              />
              <Button
                onClick={() => logoutMutation.mutate()}
                variant="outline"
                size="sm"
                disabled={logoutMutation.isPending}
                className="flex items-center space-x-2"
              >
                <LogOut className="h-4 w-4" />
                <span>{t('logout')}</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {t('welcomeBack')}
          </h1>
          <p className="text-slate-600">
            {language === 'ar' 
              ? `مرحباً، ${(companyUser as any)?.email || 'User'}` 
              : `Welcome back, ${(companyUser as any)?.email || 'User'}`
            }
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">{t('totalRevenue')}</p>
                  <p className="text-2xl font-bold text-green-600">
                    {dashboardStats.totalRevenue.toLocaleString('en-US', { style: 'currency', currency: 'SAR' })}
                  </p>
                </div>
                <DollarSign className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">{t('monthlyRevenue')}</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {dashboardStats.monthlyRevenue.toLocaleString('en-US', { style: 'currency', currency: 'SAR' })}
                  </p>
                </div>
                <TrendingUp className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">{t('invoicesSent')}</p>
                  <p className="text-2xl font-bold text-purple-600">{dashboardStats.invoicesSent}</p>
                  <p className="text-sm text-red-600">{dashboardStats.unpaidInvoices} {t('unpaidInvoices')}</p>
                </div>
                <FileText className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">{t('totalCustomers')}</p>
                  <p className="text-2xl font-bold text-orange-600">{dashboardStats.customers}</p>
                </div>
                <Users className="h-8 w-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* VoM Navigation Menu */}
        <div className="bg-white rounded-lg shadow-sm border">
          <div className="p-4">
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-8 h-8 bg-gray-300 rounded-full"></div>
              <div>
                <div className="text-sm font-medium">Welcome مرحبا</div>
                <div className="text-xs text-gray-500">Last Visit Date: 1 hour ago</div>
              </div>
            </div>

            <nav className="space-y-1">
              <div className="bg-teal-600 text-white rounded-lg p-3">
                <div className="text-sm font-medium">{t('sales')}</div>
              </div>
              <div className="ml-4 space-y-2 mt-3">
                <Link href="/customers/create">
                  <div className="text-sm text-gray-600 py-2 px-3 hover:bg-gray-50 rounded cursor-pointer">{t('customers')}</div>
                </Link>
                <Link href="/quotation/create">
                  <div className="text-sm text-gray-600 py-2 px-3 hover:bg-gray-50 rounded cursor-pointer">{t('quotation')}</div>
                </Link>
                <Link href="/proforma-invoices/create">
                  <div className="text-sm text-gray-600 py-2 px-3 hover:bg-gray-50 rounded cursor-pointer">{t('proformaInvoices')}</div>
                </Link>
                <Link href="/invoices/create">
                  <div className="text-sm text-blue-600 py-2 px-3 hover:bg-blue-50 rounded cursor-pointer font-medium">{t('invoices')}</div>
                </Link>
                <Link href="/debit-notes/create">
                  <div className="text-sm text-gray-600 py-2 px-3 hover:bg-gray-50 rounded cursor-pointer">{t('debitNotes')}</div>
                </Link>
                <Link href="/credit-notes/create">
                  <div className="text-sm text-gray-600 py-2 px-3 hover:bg-gray-50 rounded cursor-pointer">{t('creditNote')}</div>
                </Link>
                <Link href="/customer-receipts/create">
                  <div className="text-sm text-gray-600 py-2 px-3 hover:bg-gray-50 rounded cursor-pointer">{t('customerReceipts')}</div>
                </Link>
                <div className="text-sm text-gray-600 py-2 px-3 hover:bg-gray-50 rounded cursor-pointer">Sales Transactions</div>
              </div>
              
              <div className="bg-orange-100 text-orange-800 rounded-lg p-3 mt-4">
                <div className="text-sm font-medium">Purchases</div>
                <div className="text-xs">NEW</div>
              </div>
              <div className="ml-4 space-y-2 mt-3">
                <div className="text-sm text-gray-600 py-2 px-3 hover:bg-gray-50 rounded cursor-pointer">Products/Services</div>
              </div>
              
              <div className="bg-gray-100 text-gray-800 rounded-lg p-3 mt-4">
                <div className="text-sm font-medium">Accounting</div>
              </div>
            </nav>
          </div>
        </div>

        {/* Main Dashboard Content */}
        <Tabs defaultValue="overview" className="space-y-6 mt-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">{t('overview')}</TabsTrigger>
            <TabsTrigger value="invoices">{t('invoices')}</TabsTrigger>
            <TabsTrigger value="expenses">{t('expenses')}</TabsTrigger>
            <TabsTrigger value="reports">{t('reports')}</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Invoices */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                  <CardTitle className="text-lg font-semibold">{t('recentInvoices')}</CardTitle>
                  <Button size="sm" className="bg-blue-700 hover:bg-blue-800">
                    <Plus className="h-4 w-4 mr-2" />
                    {t('newInvoice')}
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentInvoices.map((invoice) => (
                      <div key={invoice.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <p className="font-medium">{invoice.id}</p>
                          <p className="text-sm text-slate-600">{invoice.customer}</p>
                          <p className="text-sm text-slate-500">{invoice.date}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">
                            {invoice.amount.toLocaleString('en-US', { style: 'currency', currency: 'SAR' })}
                          </p>
                          <Badge variant={
                            invoice.status === 'paid' ? 'default' : 
                            invoice.status === 'pending' ? 'secondary' : 'destructive'
                          }>
                            {invoice.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Recent Expenses */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                  <CardTitle className="text-lg font-semibold">Recent Expenses</CardTitle>
                  <Button size="sm" variant="outline">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Expense
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentExpenses.map((expense) => (
                      <div key={expense.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <p className="font-medium">{expense.description}</p>
                          <p className="text-sm text-slate-600">{expense.category}</p>
                          <p className="text-sm text-slate-500">{expense.date}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-red-600">
                            -{expense.amount.toLocaleString('en-US', { style: 'currency', currency: 'SAR' })}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Invoices Tab */}
          <TabsContent value="invoices" className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0">
                <CardTitle>Invoice Management</CardTitle>
                <div className="flex space-x-2">
                  <Button size="sm" variant="outline">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter
                  </Button>
                  <Button size="sm" className="bg-blue-700 hover:bg-blue-800">
                    <Plus className="h-4 w-4 mr-2" />
                    Create Invoice
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <div className="flex-1 relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                      <input
                        type="text"
                        placeholder="Search invoices..."
                        className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-700 focus:border-blue-700"
                      />
                    </div>
                  </div>
                  
                  <div className="border rounded-lg overflow-hidden">
                    <table className="w-full">
                      <thead className="bg-slate-50">
                        <tr>
                          <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Invoice ID</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Customer</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Amount</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Status</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Date</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {recentInvoices.map((invoice) => (
                          <tr key={invoice.id} className="hover:bg-slate-50">
                            <td className="px-4 py-3 text-sm font-medium">{invoice.id}</td>
                            <td className="px-4 py-3 text-sm text-slate-600">{invoice.customer}</td>
                            <td className="px-4 py-3 text-sm font-semibold">
                              {invoice.amount.toLocaleString('en-US', { style: 'currency', currency: 'SAR' })}
                            </td>
                            <td className="px-4 py-3">
                              <Badge variant={
                                invoice.status === 'paid' ? 'default' : 
                                invoice.status === 'pending' ? 'secondary' : 'destructive'
                              }>
                                {invoice.status}
                              </Badge>
                            </td>
                            <td className="px-4 py-3 text-sm text-slate-600">{invoice.date}</td>
                            <td className="px-4 py-3">
                              <div className="flex space-x-2">
                                <Button size="sm" variant="ghost">
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button size="sm" variant="ghost">
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button size="sm" variant="ghost">
                                  <Download className="h-4 w-4" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Expenses Tab */}
          <TabsContent value="expenses" className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0">
                <CardTitle>Expense Management</CardTitle>
                <Button size="sm" className="bg-blue-700 hover:bg-blue-800">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Expense
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardContent className="p-4">
                        <div className="text-center">
                          <p className="text-2xl font-bold text-red-600">
                            {dashboardStats.expenses.toLocaleString('en-US', { style: 'currency', currency: 'SAR' })}
                          </p>
                          <p className="text-sm text-slate-600">Total Expenses</p>
                        </div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4">
                        <div className="text-center">
                          <p className="text-2xl font-bold text-orange-600">
                            {recentExpenses.length}
                          </p>
                          <p className="text-sm text-slate-600">This Month</p>
                        </div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4">
                        <div className="text-center">
                          <p className="text-2xl font-bold text-blue-600">4</p>
                          <p className="text-sm text-slate-600">Categories</p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  <div className="border rounded-lg overflow-hidden">
                    <table className="w-full">
                      <thead className="bg-slate-50">
                        <tr>
                          <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Description</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Category</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Amount</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Date</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-slate-700">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {recentExpenses.map((expense) => (
                          <tr key={expense.id} className="hover:bg-slate-50">
                            <td className="px-4 py-3 text-sm font-medium">{expense.description}</td>
                            <td className="px-4 py-3 text-sm text-slate-600">{expense.category}</td>
                            <td className="px-4 py-3 text-sm font-semibold text-red-600">
                              -{expense.amount.toLocaleString('en-US', { style: 'currency', currency: 'SAR' })}
                            </td>
                            <td className="px-4 py-3 text-sm text-slate-600">{expense.date}</td>
                            <td className="px-4 py-3">
                              <div className="flex space-x-2">
                                <Button size="sm" variant="ghost">
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button size="sm" variant="ghost">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Reports Tab */}
          <TabsContent value="reports" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <div className="p-3 bg-blue-100 rounded-lg">
                      <BarChart3 className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Financial Report</h3>
                      <p className="text-sm text-slate-600">Comprehensive financial overview</p>
                    </div>
                  </div>
                  <Button className="w-full mt-4" variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Generate Report
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <div className="p-3 bg-green-100 rounded-lg">
                      <TrendingUp className="h-6 w-6 text-green-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Sales Report</h3>
                      <p className="text-sm text-slate-600">Revenue and sales analysis</p>
                    </div>
                  </div>
                  <Button className="w-full mt-4" variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Generate Report
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <div className="p-3 bg-red-100 rounded-lg">
                      <Receipt className="h-6 w-6 text-red-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Expense Report</h3>
                      <p className="text-sm text-slate-600">Detailed expense breakdown</p>
                    </div>
                  </div>
                  <Button className="w-full mt-4" variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Generate Report
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <div className="p-3 bg-purple-100 rounded-lg">
                      <FileText className="h-6 w-6 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Tax Report</h3>
                      <p className="text-sm text-slate-600">ZATCA compliant tax report</p>
                    </div>
                  </div>
                  <Button className="w-full mt-4" variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Generate Report
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <div className="p-3 bg-orange-100 rounded-lg">
                      <Users className="h-6 w-6 text-orange-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Customer Report</h3>
                      <p className="text-sm text-slate-600">Customer activity and payments</p>
                    </div>
                  </div>
                  <Button className="w-full mt-4" variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Generate Report
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <div className="p-3 bg-indigo-100 rounded-lg">
                      <Calendar className="h-6 w-6 text-indigo-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Monthly Report</h3>
                      <p className="text-sm text-slate-600">Monthly financial summary</p>
                    </div>
                  </div>
                  <Button className="w-full mt-4" variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Generate Report
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}