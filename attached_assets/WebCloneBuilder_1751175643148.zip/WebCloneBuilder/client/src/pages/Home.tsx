import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LanguageToggle } from '@/components/LanguageToggle';
import { Language, useTranslation } from '@/lib/i18n';
import { useMutation, useQuery } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from 'wouter';
import { LogOut, User, Settings, BarChart3 } from 'lucide-react';

export default function Home() {
  const [, setLocation] = useLocation();
  const [language, setLanguage] = useState<Language>('en');
  const { t } = useTranslation(language);
  const { toast } = useToast();

  // Check authentication status
  const { data: companyUser, isLoading } = useQuery({
    queryKey: ['/api/auth/company-user'],
    retry: false,
  });

  useEffect(() => {
    // Update HTML attributes for language and direction
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.body.className = `bg-slate-50 min-h-screen font-${language === 'ar' ? 'arabic' : 'english'}`;
  }, [language]);

  useEffect(() => {
    if (!isLoading && !companyUser) {
      setLocation('/');
    }
  }, [companyUser, isLoading, setLocation]);

  const logoutMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('POST', '/api/auth/company-logout');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/auth/company-user'] });
      toast({
        title: t('logout'),
        description: 'Successfully logged out',
      });
      setLocation('/');
    },
    onError: (error: any) => {
      console.error('Logout error:', error);
      toast({
        title: 'Error',
        description: 'Failed to logout',
        variant: 'destructive',
      });
    },
  });

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-slate-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!companyUser) {
    return null; // Will redirect to landing page
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* VoM Logo */}
            <div className="flex-shrink-0">
              <img
                src="https://secondsupport.getvom.com/assets/images/logo/colored-logo.png"
                alt="VoM Logo"
                className="h-8 w-auto"
              />
            </div>

            {/* Navigation */}
            <div className="flex items-center space-x-4">
              <LanguageToggle
                currentLanguage={language}
                onLanguageChange={setLanguage}
              />
              <Button
                onClick={handleLogout}
                variant="outline"
                size="sm"
                disabled={logoutMutation.isPending}
                className="flex items-center space-x-2"
              >
                <LogOut className="h-4 w-4" />
                <span>{t('logout')}</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {t('welcomeBack')}
          </h1>
          <p className="text-slate-600">
            Welcome, {companyUser.email}
          </p>
        </div>

        {/* Dashboard Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="hover:shadow-lg transition-shadow duration-200">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center space-x-2">
                <BarChart3 className="h-5 w-5 text-blue-700" />
                <span>{t('dashboard')}</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600 text-sm">
                View your company's accounting dashboard and financial reports.
              </p>
              <Button className="mt-4 w-full bg-blue-700 hover:bg-blue-800">
                Open Dashboard
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow duration-200">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center space-x-2">
                <User className="h-5 w-5 text-blue-700" />
                <span>{t('profile')}</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600 text-sm">
                Manage your user profile and account information.
              </p>
              <Button variant="outline" className="mt-4 w-full">
                View Profile
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow duration-200">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center space-x-2">
                <Settings className="h-5 w-5 text-blue-700" />
                <span>{t('settings')}</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600 text-sm">
                Configure your account settings and preferences.
              </p>
              <Button variant="outline" className="mt-4 w-full">
                Open Settings
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Company Information */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Company Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-gray-700">Email</p>
                <p className="text-slate-600">{companyUser.email}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-700">Company ID</p>
                <p className="text-slate-600">{companyUser.companyId || 'Not assigned'}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-700">User ID</p>
                <p className="text-slate-600">{companyUser.id}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
