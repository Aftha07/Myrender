import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useQuery } from "@tanstack/react-query";
import Landing from "@/pages/Landing";
import Home from "@/pages/Home";
import Dashboard from "@/pages/Dashboard";
import PasswordReset from "@/pages/PasswordReset";
import InvoiceCreate from "@/pages/InvoiceCreate";
import CustomerReceiptCreate from "@/pages/CustomerReceiptCreate";
import CustomerCreate from "@/pages/CustomerCreate";
import NotFound from "@/pages/not-found";

function Router() {
  // Check if user has an active company session
  const { data: companyUser, isLoading } = useQuery({
    queryKey: ["/api/auth/company-user"],
    retry: false,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto"></div>
          <p className="mt-4 text-slate-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <Switch>
      {/* Public routes */}
      <Route path="/reset-password" component={PasswordReset} />
      
      {/* Conditional routing based on authentication */}
      {!companyUser ? (
        <>
          <Route path="/" component={Landing} />
          <Route path="/dashboard" component={Landing} />
        </>
      ) : (
        <>
          <Route path="/" component={Dashboard} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/home" component={Home} />
          <Route path="/invoices/create">
            {() => <InvoiceCreate language={{ code: 'en', name: 'English' }} />}
          </Route>
          <Route path="/customer-receipts/create">
            {() => <CustomerReceiptCreate language={{ code: 'en', name: 'English' }} />}
          </Route>
          <Route path="/customers/create">
            {() => <CustomerCreate language={{ code: 'en', name: 'English' }} />}
          </Route>
        </>
      )}
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
