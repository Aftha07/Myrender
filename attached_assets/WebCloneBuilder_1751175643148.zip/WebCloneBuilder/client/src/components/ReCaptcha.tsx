import { useEffect, useRef } from 'react';

interface ReCaptchaProps {
  onVerify: (token: string) => void;
  onExpired?: () => void;
}

declare global {
  interface Window {
    grecaptcha: any;
    onRecaptchaLoad: () => void;
  }
}

export function ReCaptcha({ onVerify, onExpired }: ReCaptchaProps) {
  const recaptchaRef = useRef<HTMLDivElement>(null);
  const widgetId = useRef<number | null>(null);

  useEffect(() => {
    const loadRecaptcha = () => {
      if (window.grecaptcha && recaptchaRef.current && widgetId.current === null) {
        try {
          widgetId.current = window.grecaptcha.render(recaptchaRef.current, {
            sitekey: '6LeAqLMZAAAAAGIXs7M0lwUFylfcVnHXCd92j4ye',
            callback: onVerify,
            'expired-callback': onExpired,
          });
        } catch (error) {
          console.warn('reCAPTCHA already rendered or error:', error);
        }
      }
    };

    if (window.grecaptcha && window.grecaptcha.render) {
      loadRecaptcha();
    } else {
      window.onRecaptchaLoad = loadRecaptcha;
      
      // Load reCAPTCHA script if not already loaded
      if (!document.querySelector('script[src*="recaptcha"]')) {
        const script = document.createElement('script');
        script.src = 'https://www.google.com/recaptcha/api.js?onload=onRecaptchaLoad&render=explicit';
        script.async = true;
        script.defer = true;
        document.head.appendChild(script);
      }
    }

    return () => {
      if (widgetId.current !== null && window.grecaptcha) {
        try {
          window.grecaptcha.reset(widgetId.current);
        } catch (error) {
          console.warn('Error resetting reCAPTCHA:', error);
        }
        widgetId.current = null;
      }
    };
  }, [onVerify, onExpired]);

  return <div ref={recaptchaRef} className="flex justify-center" />;
}
