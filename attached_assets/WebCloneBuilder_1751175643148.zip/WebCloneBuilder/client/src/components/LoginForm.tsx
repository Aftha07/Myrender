import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';

import { Language, useTranslation } from '@/lib/i18n';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';
import { Link } from 'wouter';

interface LoginFormProps {
  language: Language;
  onLoginSuccess: () => void;
}

interface LoginData {
  email: string;
  password: string;
}

export function LoginForm({ language, onLoginSuccess }: LoginFormProps) {
  const { t } = useTranslation(language);
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const loginMutation = useMutation({
    mutationFn: async (data: LoginData) => {
      const response = await apiRequest('POST', '/api/auth/company-login', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: t('welcomeBack'),
        description: t('loginButton'),
      });
      onLoginSuccess();
    },
    onError: (error: any) => {
      console.error('Login error:', error);
      toast({
        title: t('loginFailed'),
        description: error.message || t('loginFailed'),
        variant: 'destructive',
      });
    },
  });

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.email) {
      newErrors.email = t('emailRequired');
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = t('emailInvalid');
    }

    if (!formData.password) {
      newErrors.password = t('passwordRequired');
    } else if (formData.password.length < 6) {
      newErrors.password = t('passwordMinLength');
    }



    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      loginMutation.mutate(formData);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };



  return (
    <Card className="w-full max-w-md shadow-lg border border-slate-200">
      <CardContent className="p-8">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-semibold text-gray-900">
            {t('loginTitle')}
          </h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
              {t('emailLabel')}
            </Label>
            <Input
              type="email"
              id="email"
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              placeholder={t('emailPlaceholder')}
              className={`w-full ${errors.email ? 'border-red-500' : 'border-slate-300'} focus:ring-2 focus:ring-blue-700 focus:border-blue-700`}
              disabled={loginMutation.isPending}
            />
            {errors.email && (
              <p className="mt-1 text-sm text-red-600">{errors.email}</p>
            )}
          </div>

          <div>
            <Label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
              {t('passwordLabel')}
            </Label>
            <Input
              type="password"
              id="password"
              value={formData.password}
              onChange={(e) => handleInputChange('password', e.target.value)}
              placeholder={t('passwordPlaceholder')}
              className={`w-full ${errors.password ? 'border-red-500' : 'border-slate-300'} focus:ring-2 focus:ring-blue-700 focus:border-blue-700`}
              disabled={loginMutation.isPending}
            />
            {errors.password && (
              <p className="mt-1 text-sm text-red-600">{errors.password}</p>
            )}
          </div>

          <div className="flex items-center justify-end">
            <Link
              href="/reset-password"
              className="text-sm text-blue-700 hover:text-blue-800 transition-colors duration-200"
            >
              {t('forgotPassword')}
            </Link>
          </div>



          <Button
            type="submit"
            disabled={loginMutation.isPending}
            className="w-full bg-blue-700 hover:bg-blue-800 text-white font-medium py-3 transition-all duration-200"
          >
            {loginMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                {t('loggingIn')}
              </>
            ) : (
              t('loginButton')
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
