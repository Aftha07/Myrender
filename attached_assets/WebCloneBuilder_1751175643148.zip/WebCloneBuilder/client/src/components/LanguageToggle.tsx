import { Language } from '@/lib/i18n';

interface LanguageToggleProps {
  currentLanguage: Language;
  onLanguageChange: (language: Language) => void;
}

export function LanguageToggle({ currentLanguage, onLanguageChange }: LanguageToggleProps) {
  const toggleLanguage = () => {
    const newLanguage = currentLanguage === 'en' ? 'ar' : 'en';
    onLanguageChange(newLanguage);
  };

  return (
    <button
      onClick={toggleLanguage}
      className="text-slate-600 hover:text-blue-700 transition-colors duration-200 font-medium"
    >
      {currentLanguage === 'en' ? 'العربية' : 'English'}
    </button>
  );
}
